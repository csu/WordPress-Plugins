=== Conceal WordPress ===
Contributors: Christopher Su
Donate link: http://christophersu.org/wp-donate/
Tags: wordpress, hide, conceal, header, head, code
Requires at least: 2.7
Tested up to: 3.4
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Cleans up the output of wp_head and adds root relative URLs.

== Description ==

Cleans up the output of wp_head so it becomes less apparent that your WordPress installation is running WordPress. It also adds root relative URLs and makes the HTML output of WordPress much cleaner. Based off the work of [Ben Word](http://benword.com) and [Scott Walkinshaw](http://terrordome.ca/).

== Installation ==

1. Upload the plugin to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently asked questions ==



== Screenshots ==



== Changelog ==



== Upgrade notice ==

